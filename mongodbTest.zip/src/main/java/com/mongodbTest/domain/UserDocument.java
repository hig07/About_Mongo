package com.mongodbTest.domain;

import javax.annotation.Generated;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;

@Document("event")
@Getter
@Setter
public class UserDocument {
	
	@Id
	private String _id;
	
	private String title;
	
	private String image;
}
