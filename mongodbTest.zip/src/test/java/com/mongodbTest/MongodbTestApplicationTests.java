package com.mongodbTest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mongodbTest.domain.UserDocument;
import com.mongodbTest.domain.UserRepository;

@SpringBootTest
class MongodbTestApplicationTests {
	
	@Autowired
	UserRepository userRepository;

	@Test
	void 데이터저장() {
		UserDocument userDocument = new UserDocument();
		
		userDocument.set_id("1");
		userDocument.setTitle("첫 개시");
		userDocument.setImage("이미지미지");
		
		userRepository.save(userDocument);
	}

}
